from django.contrib import admin
# from .models import Question


# Register your models here.


# this model is make for store the questions
# from django.contrib import admin

# admin.site.register(Question)